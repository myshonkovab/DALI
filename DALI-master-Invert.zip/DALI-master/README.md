# DALI
Simple DALI controller using Arduino
To control DALI lighting fixtures I created DALI library. You can use it to work with DALI devices. At the moment you can not get responses from devices. But you can find whether devices give response or not. It's enough to control and initialize DALI luminaires.
https://create.arduino.cc/projecthub/NabiyevTR/simple-dali-driver-506e44
